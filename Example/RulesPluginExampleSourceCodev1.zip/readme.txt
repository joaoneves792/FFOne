KnockoutQualifying:

This is the actual source of the shipped plugin and demonstrates how to customize who participates in qualifying (and in which one, if there is more than one). Done carefully, it should also be expandable to who participates in multiple race sessions and in what grid order. For example, reverse race grids should be possible, but we have never developed and tested such a plugin. This plugin also demonstrates a way to store user-configurable values in the CustomPluginVariables.JSON file.

StockCarRules:

This is the actual source of the shipped plugin and demonstrates how to configure some rules, particularly ordering cars during caution periods. rFactor2 calculates many variables and passes them to the plugin, allowing some to be edited and returned. Some other rules are still controlled by rFactor2 and can only be configured through RFM and GDB entries. There is no way to override those at the moment, but it is a known limitation.

This plugin also demonstrates a way to store user-configurable values in the CustomPluginVariables.JSON file. There is also some simple logging functionality for help debugging.